@testable import KSPlayer
import XCTest

class VideoPlayerViewTest: XCTestCase {
    func testResize() {}
}
