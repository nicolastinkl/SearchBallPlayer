@testable import KSPlayer
import XCTest

class VideoPlayerControllerTest: XCTestCase {
    func testResize() {}
}
